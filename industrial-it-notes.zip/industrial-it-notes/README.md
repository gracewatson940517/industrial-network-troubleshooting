# Industrial IT Operations Notes

Industrial IT / OT infrastructure operation notes and troubleshooting records.

## Contents

- Industrial weighbridge system operations
- Docker deployment procedures
- Industrial network troubleshooting
- FTP/TLS compatibility issues
- Industrial data acquisition platform maintenance
- Frontend/backend deployment workflows
- Containerized application operations

## Technologies

- Docker
- Linux
- Nginx
- Harbor
- Industrial Data Collection
- TCP/IP
- FTP
- TLS
- Industrial Network

## Focus Areas

- Industrial IT Infrastructure
- OT Operations
- Industrial Edge Systems
- Deployment Automation
- Troubleshooting
- System Stability
